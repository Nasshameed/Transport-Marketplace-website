
    
	  <div class="conntainer">
		 
    <div class="view">


    </div>
    <div class="flight">



    </div>
    <div class="bus">



    </div>
    <div class="train">



    </div>
    <div class="ship">



    </div>
    <div class="sea">



    </div>
  
    
</div>