<?php require_once "header.php";?>
<?php //require_once "./.php";?>
<?php require_once "./nav.php";?>
<?php require_once "./slide.php";?>
<?php require_once "./main.php";?>
<?php require_once "./footer.php";?>