<?php
if ($actype == "company") {
    // code...
    require_once "ccc.php";
}elseif ($actype == "user"){
    // code...
     require_once "uuu.php";

}
?>