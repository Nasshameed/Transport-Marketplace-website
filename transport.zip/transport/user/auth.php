<?php
// Initialize the session
// session_start();
 
// Check if the user is logged in, if not then redirect him to login page
// if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
   // header("location: http://localhost/rayandata/404/404.html");
    // exit;
   
    
//}
?>
<?php
// Initialize the session
session_start();

// Define the session timeout duration (e.g., 1800 seconds = 30 minutes)
$inactive = 120;

// Check if the user is logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("Location: index.php");
    exit;
}

// Check if the last activity session variable is set
if (isset($_SESSION['last_activity'])) {
    // Calculate the session lifetime
    $session_life = time() - $_SESSION['last_activity'];

    // If session has timed out, destroy it and redirect to the login page
    if ($session_life > $inactive) {
        session_unset();     // Unset $_SESSION variable for the run-time
        session_destroy();   // Destroy session data in storage
        header("Location: signin.php");
        exit;
    }
}

// Update the last activity time stamp
$_SESSION['last_activity'] = time();

// Establish a database connection
// Assuming $conn is the connection variable
// Make sure to replace 'DB_HOST', 'DB_USER', 'DB_PASS', and 'DB_NAME' with your database credentials
//$conn = new mysqli('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');
require_once "conn.php";
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Securely retrieve the username from the session
$session1 = $conn->real_escape_string($_SESSION["username"]);

// Prepare and execute the SQL statement
$sql = "SELECT * FROM `user/company` WHERE username = '$session1'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $actype = $row["actype"];
    $name = $row["name"];
    $company_name = $row["company_name"];
 }// else {
//     // Handle case where no customer is found
//     // e.g., set $amount to 0 or some default value
//     $amount = 0;
// }

// Close the database connection
$conn->close();
?>


