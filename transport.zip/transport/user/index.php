<?php require_once "header.php"?>
<?php require_once "sidebar.php"?>
<?php require_once "navbar.php"?>
<?php require_once "main.php"?>
<?php require_once "footer.php"?>
