<?php 
require_once "./header.php";
require_once "./conn.php";

// Define variables and initialize with empty values
$name = $email = $phone = $uc = $city = $password = $cpassword = $me = $cname = "";
$name_err = $email_err = $phone_err = $uc_err = $password_err = $cpassword_err = $me_err = $cname_err = $city_err = "";

// Generate a random ID
$id = "";
for ($i = 0; $i < 3; $i++) {
   $id .= rand(0, 9);
}

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate Full Name
    if (empty(trim($_POST["name"]))) {
        $name_err = "Please enter your full name.";
    } else {
        $name = trim($_POST["name"]);
    }

    // Validate Email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } else {
        $email = trim($_POST["email"]);
    }

    // Validate Account Type (User/Company)
    if (empty(trim($_POST["uc"])) || $_POST["uc"] == "Select Your Aim") {
        $uc_err = "Please select your account type.";
    } else {
        $uc = trim($_POST["uc"]);
    }
    
    // Validate Company Name if account type is company
    if ($uc == "company" && empty(trim($_POST["cname"]))) {
        $cname_err = "Please enter your company name.";
    } else {
        $cname = trim($_POST["cname"]);
    }

    // Validate Phone Number
    if (empty(trim($_POST["phone"]))) {
        $phone_err = "Please enter your phone number.";
    } else {
        $phone = trim($_POST["phone"]);
    }

    // Validate City
    if (empty(trim($_POST["city"])) || $_POST["city"] == "Select Your City") {
        $city_err = "Please select your city.";
    } else {
        $city = trim($_POST["city"]);
    }

    // Validate Password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Validate Confirm Password
    if (empty(trim($_POST["cpassword"]))) {
        $cpassword_err = "Please confirm password.";
    } else {
        $cpassword = trim($_POST["cpassword"]);
        if (empty($password_err) && ($password != $cpassword)) {
            $cpassword_err = "Password did not match.";
        }
    }

    // Check if there are any errors before inserting into database
    if (empty($name_err) && empty($email_err) && empty($phone_err) && empty($uc_err) && empty($cname_err) && empty($password_err) && empty($cpassword_err) && empty($city_err)) {
        // Check if the email, phone number, or company name are unique
        $sql = "SELECT id FROM `user/company` WHERE email = ? OR phone = ? OR (company_name = ? AND company_name != '')";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sss", $email, $phone, $cname);

            if ($stmt->execute()) {
                $stmt->store_result();

                if ($stmt->num_rows == 0) {
                    // Insert data into database
                    $sql = "INSERT INTO `user/company` (name, email, phone, city, actype, password, company_name, id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    
                    if ($stmt = $conn->prepare($sql)) {
                        $stmt->bind_param("ssssssss", $name, $email, $phone, $city, $uc, $password, $cname, $id);

                        if ($stmt->execute()) {
                            // Registration was successful
                            $me = "<p class='text-info'>Your registration was successful.</p>";
                        } else {
                            $me = "<p class='text-danger'>Oops! Something went wrong. Please try again later.</p>";
                        }
                    } else {
                        $me = "<p class='text-danger'>Error preparing insert statement: " . $conn->error . "</p>";
                    }
                } else {
                    if (!empty($cname)) {
                        $cname_err = "This company name is already taken.";
                    }
                    $email_err = "This email is already taken.";
                    $phone_err = "This phone number is already taken.";
                }
            } else {
                $me = "<p class='text-danger'>Oops! Something went wrong. Please try again later.</p>";
            }
            $stmt->close();
        } else {
            $me = "<p class='text-danger'>Error preparing select statement: " . $conn->error . "</p>";
        }
    }
    $conn->close();
}
?>

<section class="sign-in-form py-3 mt-5">
    <div class="container py-3 mt-3">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="form mt-4 rounded shadow p-5">
            <h1 class="text-center py-3">Sign Up Form <i class="fa fa-users text-info py-3 text-center"></i></h1>
            <?php echo $me; ?>
            <div class="form-group">
                <label><i class="fa fa-user"></i> Full Name</label>
                <input type="text" name="name" placeholder="Enter Your Full Name Here." class="rounded-5 shadow-3 form-control py-3" value="<?php echo htmlspecialchars($name); ?>">
                <span class="text-danger"><?php echo $name_err; ?></span>
            </div>
            <div class="form-group">
                <label><i class="fa fa-phone-square"></i> Phone Number</label>
                <input type="text" name="phone" placeholder="Enter Your Phone Number Here." class="rounded-5 shadow-3 form-control py-3" value="<?php echo htmlspecialchars($phone); ?>">
                <span class="text-danger"><?php echo $phone_err; ?></span>
            </div>
            <div class="form-group">
                <label><i class="fa fa-book"></i> User/Company</label>
                <select name="uc" class="form-control rounded shadow">
                    <option value="user" <?php echo ($uc == 'user') ? 'selected' : ''; ?>>I am a User</option>
                    <option value="company" <?php echo ($uc == 'company') ? 'selected' : ''; ?>>I am a Company</option>
                </select>
                <span class="text-danger"><?php echo $uc_err; ?></span>
            </div>
            <div class="form-group">
                <label><i class="fa fa-envelope"></i> Company Name</label>
                <input type="text" name="cname" placeholder="Enter Your Company Name Here." class="rounded-5 shadow-3 form-control py-3" value="<?php echo htmlspecialchars($cname); ?>">
                <span class="text-danger"><?php echo $cname_err; ?></span>
            </div>
            <div class="form-group">
                <label><i class="fa fa-map-marker"></i> Select Your City</label>
      
<select name="city" class="rounded shadow form-control">
   <?php 
                             require_once "./conn.php";
// SQL query to select all records from the "bank" table
$sql = "SELECT * FROM city";

// Execute the query
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
      
        echo '<option value="'.$row['name'].'" class="text-capitalize">'.$row['name'].'</option>';
    
        
       
    }
} else {
    echo "<h1 class='text-danger'>No Account Details Added Yet</h1>";
}

// Close connection
//$conn->close();

                             ?>
</select>

                <span class="text-danger"><?php echo $city_err; ?></span>
            </div>
            <div class="form-group">
                <label><i class="fa fa-envelope"></i> Email Address</label>
                <input type="email" name="email" placeholder="Enter Your Email Address Here." class="form-control rounded shadow" value="<?php echo htmlspecialchars($email); ?>">
                <span class="text-danger"><?php echo $email_err; ?></span> 
            </div>
            <div class="form-group pb-2">
                <label><i class="fa fa-lock"></i> Password</label>
                <input type="password" name="password" placeholder="Enter Your Password Here." class="rounded-5 shadow-3 form-control py-3" value="<?php echo htmlspecialchars($password); ?>">
                <span class="text-danger"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group pb-2">
                <label><i class="fa fa-lock"></i> Confirm Password</label>
                <input type="password" name="cpassword" placeholder="Enter Your Confirm Password Here." class="rounded-5 shadow-3 form-control py-3" value="<?php echo htmlspecialchars($cpassword); ?>">
                <span class="text-danger"><?php echo $cpassword_err; ?></span>
            </div>
            <div class="form-group py-3">
                <input type="checkbox" class="rounded-5 shadow-3 py-3" required> Agree to our Terms & Condition
            </div>
            <div class="form-group py-3">
                <button class="btn btn-outline-info rounded-5 shadow"><i class="fa fa-registered"></i> Sign Up</button>
            </div>
            <div class="py-2 text-center">
                <p>Already have an Account? <a href="sign-in.php" style="text-decoration: none; color:#000080;">Sign In</a></p>
            </div>
        </form>
    </div>
</section>
