<?php require_once "./assets/header1.php";?>
<?php //require_once "assets/sidebar.php";?>
<?php //require_once "assets/navbar.php";?>
<?php require_once "./assets/login.php";?>
<?php require_once "./assets/footer1.php";?>