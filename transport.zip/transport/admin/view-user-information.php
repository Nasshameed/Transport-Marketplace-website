<?php require_once "./assets/header.php";?>
<?php require_once "./assets/sidebar.php";?>
<?php require_once "./assets/navbar.php";?>
<?php require_once "./assets/view-user-information.php";?>
<?php require_once "./assets/footer.php";?>