<?php require_once "./assets/header.php";?>
<?php require_once "./assets/sidebar.php";?>
<?php require_once "./assets/navbar.php";?>
<?php require_once "./assets/delete_user.php";?>
<?php require_once "./assets/footer.php";?>