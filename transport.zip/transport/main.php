<div class="container-fluid py-5">
       <div class="row">
		  
		   <div class="col-md-6 py-2">
			   <h6 class="text-info py-3">ABOUT US</h6>
			   <h2 class="py-2">Quick Transport and Logistics Solutions</h2>
			   <p class="py-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet</p>
			   
			   <div style="display: flex; flex-direction: row; gap:1rem" id="share">
				   <div class="py-4" style="flex:1">
					   <center><i class="fa fa-globe text-info py-2" style="font-size: 100px;"></i></center>
					   <h6 class="text-info">Global Coverage</h6>
                      <p>Our global delivery service ensures you receive our products no matter where you are, with a seamless and reliable shipping experience. Shop confidently, knowing our robust logistics network will bring our offerings to your doorstep anywhere in the world.</p>
				   </div>
				   <div class="py-4" style="flex:1">
					   <center><i class="fa fa-truck text-info py-2" style="font-size: 100px;"></i></center>
					   <h6 class="text-info">On Time Delivery</h6>
                       <p>"On Time Delivery" means we guarantee your orders arrive precisely when expected, thanks to our meticulous planning and advanced logistics systems. Trust our dedicated team to ensure your delivery experience is smooth, reliable, and free of delays.</p>
				   </div>
			   </div>
			   <div class="share-link">
			   <a href="#" class="btn btn-info py-2 px-2 rounded shadow">Explore More</a></div>
		   </div>
		    <div class="col-md-6 py-2">
			   <img src="image/about.jpg" style="width: 100%">
		   </div>
	</div></div>
	  
   <div class="container-fluid py-5">
       <div class="row">
		    <div class="col-md-6 py-2">
			   <img src="image/feature.jpg" style="width: 100%">
		   </div>
		  
		   <div class="col-md-6 py-2">
			   <h6 class="text-info py-3">OUR FEATURES</h6>
			   <h2 class="py-3"><i class="fa fa-globe px-3 text-info"></i> We Are Trusted Logistics Company</h2> 
			   <h2 class="py-3"><i class="fa fa-truck px-3 text-info"></i> On Time Delivery</h2> 
			   <h2 class="py-3"><i class="fa fa-phone px-3 text-info"></i> 24/7 Telephone Support</h2>
				   
			  
			   <div class="share-link">
				   <p class="py-2 px-5 text-center text-info" style="line-height: 30px;">
					   we are committed to ensuring your orders arrive precisely when expected. Our meticulous planning and advanced logistics systems are designed to provide reliable delivery schedules, so you never have to worry about delays. We understand the importance of timely deliveries for your plans and operations, and we strive to meet our promises consistently. Our dedicated team works around the clock to monitor shipments and address any potential issues promptly, ensuring that your delivery experience is both smooth and dependable. With our "On Time Delivery" service, you can trust that your orders will be in your hands exactly when you need them.
				   </p>
		   </div>
		   
	</div></div>