<?php require_once "./header.php";?>
<?php
// Start the session
session_start();
$me = "";

// Check if the user is already logged in, if yes then redirect to welcome page
if(isset($_SESSION['username'])){
    header("Location: ./user");
    exit;
}

// Include the database configuration file
include('conn.php');

// Initialize variables
$username = $password = "";
$username_err = $password_err = "";

// Process form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "<span class='text-danger'>Please enter username.</span>";
    } else{
        $username = trim($_POST["username"]);
    }

    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "<span class='text-danger'>Please enter your password.</span>";
    } else{
        $password = trim($_POST["password"]);
    }

    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT serial, email, password FROM `user/company` WHERE email = ?";

        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);

            // Set parameters
            $param_username = $username;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);

                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $stored_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if($password == $stored_password){
                            // Password is correct, so start a new session
                            session_start();

                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;

                            // Redirect user to welcome page
                            header("Location: ./user");
                            exit;
                        } else{
                            // Display an error message if password is not valid
                             $password_err = "<span class='text-danger'>The password you entered was not valid.</span>";
                        }
                    }
                } else{
                    // Display an error message if username doesn't exist
                     $username_err = "<span class='text-danger'>No account found with that username.</span>";
                }
            } else{
                $me = "<span class='text-danger'>Oops! Something went wrong. Please try again later.</span>";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Close connection
    mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="path/to/your/bootstrap.css">
    <link rel="stylesheet" href="path/to/font-awesome.css">
</head>
<body>
<section class="sign-in-form py-3 mt-5">
    <div class="container py-3 mt-3">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="form mt-4 rounded shadow p-5">
            <h1 class="text-center py-3">Sign In Form <i class="fa fa-users text-info py-3 text-center"></i></h1>
            <p><?php if ($me) echo $me; ?></p>
            <div class="form-group">
                <label><i class="fa fa-envelope"></i> E-mail Address</label>
                <input type="email" name="username" placeholder="Enter Your E-mail Here" class="rounded-5 shadow-3 form-control py-3" value="<?php echo $username; ?>">
                <span><?php echo $username_err; ?></span>
            </div>
            <div class="form-group pb-2">
                <label><i class="fa fa-lock"></i> Password</label>
                <input type="password" name="password" placeholder="Enter Your Password Here" class="rounded-5 shadow-3 form-control py-3">
                <span><?php echo $password_err; ?></span>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <div class="form-group py-3">
                    <input type="checkbox" class="rounded-5 shadow-3 py-3"> Remember me
                </div>
                <div class="form-group py-3">
                    <a href="forgotten.php" style="text-decoration: none;">Forgotten Password.</a>
                </div>
            </div>
            <div class="form-group py-3">
                <button class="btn btn-outline-info rounded-5 shadow"><i class="fa fa-sign-in"></i> Sign In</button>
            </div>
            <div class="py-2 text-center">
                <p>Don't have an Account <a href="signup.php" style="text-decoration: none; color:#000080;">Sign Up</a></p>
            </div>
        </form>
    </div>
</section>
</body>
</html>
