<?php require_once "./header.php";?>
<section class="sign-in-form py-3 mt-5">
	<div class="container py-3 mt-3">
		<form method="" action="" class="form mt-4 rounded shadow p-5">
			<h1 class="text-center py-3">Sign In Form <i class="fa fa-users text-info py-3 text-center"></i></h1>
			<div class="form-group">
				<label><i class="fa fa-envelope"></i> E-mail Addres</label>
			</div>
				<div class="form group pb-2">
					<input type="email" name="username" placeholder="Enter Your E-mail Hear." value="" class="rounded-5 shadow-3 form-control py-3">
				</div>
			<div class="form-group pb-2">
				<label><i class="fa fa-lock"></i> Password</label>
			</div>
				<div class="form group">
					<input type="password" name="password" placeholder="Enter YourPassword Hear." value="" class="rounded-5 shadow-3 form-control py-3">
				</div>
			<div style="display: flex; justify-content: space-between;">
				<div class="form group py-3">
					<input type="checkbox" class="rounded-5 shadow-3 py-3"> Remember me
				</div>
			     <div class="form group py-3">
					<a href="forgotten.php" style="text-decoration: none;">Forgotten Password.</a>
				</div>
			</div>
			
				
			<div class="form group py-3">
				<button class="btn btn-outline-info rounded-5 shadow"><i class="fa fa-sign-in"></i> Sign In</button>
				</div>
			
			<div class="py-2 text-center">
				<p>Don't have an Account <a href="signup.php" style="text-decoration: none; color:#000080;">Sign Up</a></p>
			</div>
			
			
		</form>
	</div>
</section>