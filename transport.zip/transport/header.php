<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Transportation Marketplace </title>

    <!-- Bootstrap -->
    <link href="css/bootstrap-4.3.1.css" rel="stylesheet">
	  <!--	  font-awesome-->
	  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	  <style>

.view{
    background-image: url(image/bg.png);
    height: 350px;
    width: 100%;
    background-repeat: repeat;
    animation: view 120s infinite linear;
    position: absolute;
    left: 0;
    top: auto;
    bottom: 10px;
    z-index: 1;
    animation-timing-function: linear;
    animation-direction: reverse;
}

.flight {
    background-image: url(image/flight.png);
    height: 167px;
    width: 261px;
    background-repeat: repeat;
    position: absolute;
    left: 0;
    top: 52px;
    z-index: 1;
    animation: flight 10s infinite;
    animation-timing-function: linear;
    animation-direction: normal;
    
}
@keyframes flight {
  0%   { left: 0px; top: 0px;}
  25%   { left: 100px; top: -35px;}
  50%   { left: 150px; top: -50px;}
  100%  { left:250px; top: -98px;}
  
}
.conntainer{border: 1px solid #000;
    height: 314px;
    position: relative;
    overflow: hidden;
}
.bus{    background-image: url(image/bus.png);
    height: 216px;
    width: 241px;
    z-index: 999;
    position: absolute;
    bottom: -42px;
    background-repeat: no-repeat;
    animation: bus 30s infinite;
    animation-timing-function: linear;
    animation-direction: reverse;
}
@keyframes bus {
  0%   { left: 0px; bottom: -42px;}
  100%  { left:100%;     bottom: -42px;}
  
}
.train{    background-image: url(image/train.png);
    height: 216px;
    width: 1000px;
    z-index: 1;
    position: absolute;
    bottom: -42px;
    background-repeat: no-repeat;
    animation: bus 10s infinite;
    animation-timing-function: linear;
    animation-direction: normal;
}
@keyframes bus {
  0%   { left: 0px; bottom: -42px;}
  100%  { left:100%;    bottom: -42px;}
  
}

.ship{  background-image: url(image/ship.png);
    height: 216px;
    width: 345px;
    z-index: 999;
    position: absolute;
    bottom: -42px;
    background-repeat: no-repeat;
    animation: ship 20s infinite;
    animation-timing-function: linear;
    animation-direction: normal;
}

@keyframes ship {
  0%   { left: 0px; bottom: -71px;}
  100%  { left:100%;    bottom: -71px;}
  
}
.sea{ background-image: url(image/sea.png);
    height: 145px;
    width: 100%;
    z-index: 1;
    position: absolute;
    bottom: -42px;
    background-repeat: repeat;
   

}
footer p {z-index: 999;
    position: absolute;
    bottom: 0;
    text-align: center;
    width: 100%;
    font-size: 19px;
    font-weight: bold;
    text-shadow: 3px 1px 1px #fff;} 
		  @media (max-width:600px){
			  #share{
				  flex-direction: row-reverse !important;
			  }
		  }
    </style>

  </head>
  <body>