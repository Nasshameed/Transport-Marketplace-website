<?php 
require_once "./header.php";
require_once "./conn.php";
$email = $me = $name = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate email
    if (empty(trim($_POST["email"]))) {
        $me = "<p class='text-danger'>Please enter your email.</p>";
    } else {
        $email = trim($_POST["email"]);
    }

    if (!empty($email)) {
        // Prepare and execute the SQL statement
        $sql = "SELECT * FROM `user/company` WHERE email = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $email);
            
            if ($stmt->execute()) {
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $email = $row["email"];
                    $password = $row["password"];
                    $name = $row["name"];
                } else {
                    $me = "<p class='text-danger'>No user with this email in our database.</p>";
                }
            } else {
                $me = "<p class='text-danger'>Oops! Something went wrong. Please try again later.</p>";
            }

            // Close the statement
            $stmt->close();
        } else {
            $me = "<p class='text-danger'>Oops! Something went wrong. Please try again later.</p>";
        }
    }

    // Close the database connection
    $conn->close();
}
?>

<section class="sign-in-form py-3 mt-5">
    <div class="container py-3 mt-3">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="form mt-4 rounded shadow p-5">
            <h1 class="text-center py-3">Forgotten Password Form <i class="fa fa-lock text-info py-3 text-center"></i></h1>
            <?php echo $me; ?>
            <div class="form-group">
                <label><i class="fa fa-envelope"></i> E-mail Address</label>
                <input type="email" name="email" placeholder="Enter Your E-mail Here." value="<?php echo htmlspecialchars($email); ?>" class="rounded-5 shadow-3 form-control py-3">
            </div>
            <div class="form-group py-3">
                <button type="submit" name="rate" class="btn btn-outline-info rounded-5 shadow"><i class="fa fa-send"></i> Send</button>
            </div>
            <?php 
            if (!empty($name) && !empty($email) && !empty($password)) {
                echo "<p class='text-capitalize'>Full Name: ". $name . "</p>";
                echo "<p class='text-capitalize'>E-mail: ". $email . "</p>";
                echo "<p class='text-capitalize'>Password: ". $password . "</p>";
            }
            ?>
            <div class="py-2 text-center">
                <p>I know my Password <a href="sign-in.php" style="text-decoration: none; color:#000080;">Sign In</a></p>
            </div>
        </form>
    </div>
</section>
